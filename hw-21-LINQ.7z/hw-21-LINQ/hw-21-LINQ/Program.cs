﻿class Good
{
    public int Id { get; set; }
    public string Title { get; set; }
    public double Price { get; set; }
    public string Category { get; set; }
}

class Program
{
    static void Main()
    {
        var goods = new List<Good>
        {
            new Good { Id = 1, Title = "Nokia 1100", Price = 450.99, Category = "Mobile" },
            new Good { Id = 2, Title = "Iphone 4", Price = 5000, Category = "Mobile" },
            new Good { Id = 3, Title = "Refregirator 5000", Price = 2555, Category = "Kitchen" },
            new Good { Id = 4, Title = "Mixer", Price = 150, Category = "Kitchen" },
            new Good { Id = 5, Title = "Magnitola", Price = 1499, Category = "Car" },
            new Good { Id = 6, Title = "Samsung Galaxy", Price = 3100, Category = "Mobile" },
            new Good { Id = 7, Title = "Auto Cleaner", Price = 2300, Category = "Car" },
            new Good { Id = 8, Title = "Owen", Price = 700, Category = "Kitchen" },
            new Good { Id = 9, Title = "Siemens Turbo", Price = 3199, Category = "Mobile" },
            new Good { Id = 10, Title = "Lighter", Price = 150, Category = "Car" }
        };

        Console.WriteLine("1 Task");
        var expensiveMobiles = goods
            .Where(g => g.Category == "Mobile" && g.Price > 1000)
            .Select(g => new { g.Title, g.Price })
            .ToList();

        expensiveMobiles.ForEach(m => Console.WriteLine($"Title: {m.Title}, Price: {m.Price}"));

        Console.WriteLine("\n2 Task");
        var nonKitchenExpensiveGoods = goods
            .Where(g => g.Category != "Kitchen" && g.Price > 1000)
            .Select(g => new { g.Title, g.Price, g.Category })
            .ToList();

        nonKitchenExpensiveGoods.ForEach(g => Console.WriteLine($"Title: {g.Title}, Price: {g.Price}, Category: {g.Category}"));

        Console.WriteLine("\n3 Task");
        var averagePrice = goods.Average(g => g.Price);
        Console.WriteLine($"Average Price: {averagePrice}");

        Console.WriteLine("\n4 Task");
        var uniqueCategories = goods
            .Select(g => g.Category)
            .Distinct()
            .ToList();

        uniqueCategories.ForEach(c => Console.WriteLine(c));

        Console.WriteLine("\n5 Task");
        var sortedGoods = goods
            .OrderBy(g => g.Title)
            .Select(g => new { g.Title, g.Category })
            .ToList();

        sortedGoods.ForEach(g => Console.WriteLine($"Title: {g.Title}, Category: {g.Category}"));

        Console.WriteLine("\n6 Task");
        var carAndMobileCount = goods
            .Count(g => g.Category == "Car" || g.Category == "Mobile");

        Console.WriteLine($"Total count of Car and Mobile goods: {carAndMobileCount}");

        Console.WriteLine("\n7 Task");
        var categoryCounts = goods
            .GroupBy(g => g.Category)
            .Select(g => new { Category = g.Key, Count = g.Count() })
            .ToList();

        categoryCounts.ForEach(c => Console.WriteLine($"Category: {c.Category}, Count: {c.Count}"));
    }
}
